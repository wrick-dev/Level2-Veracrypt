from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import sys
import math
import os
import csv
def entropy(string):
	prob = [ float(string.count(c)) / len(string) for c in dict.fromkeys(list(string)) ]
	entropy = - sum([ p * math.log(p) / math.log(2.0) for p in prob ])
	return entropy
	
def readsignatures(filename):	
	ifile = open(filename, "rU")
	reader = csv.reader(ifile, delimiter=",")
	rownum = 0	
	signatures = []

	for row in reader:
		signatures.append (row)
		rownum += 1

	ifile.close()
	return signatures


app = Flask(__name__)

@app.route('/upload')
def upload():
   return render_template('upload.html')
	
@app.route('/uploader', methods = ['GET', 'POST'])
def uploader():
   if request.method == 'POST':
   	blob = request.files['file'].read()
   	size = len(blob)
   	f = request.files['file']									
   	if (size % 512 == 0):
   		size = "Passed ("+str(size % 512)+")"
   	else:
   		size = "Failed ("+str(size % 512)+")"
   		return size+" Not a Veracrypt file"

   	chunk_size = 2048
   	data = request.files['file'].read(chunk_size)
   	entropytest = entropy(data)
   	if entropytest > 7.9:
   		entropytest = "Passed ("+str(entropytest)+")"
   	else:
   		entropytest = "Failed ("+str(entropytest)+")"
   		return entropytest+" Not a Veracrypt file"
   	signatures = readsignatures("signatures.csv")
   	file = request.files['file'].read(32)
   	header = " ".join(['{:02X}'.format(byte) for byte in file])
   	detected = ""
   	for i in range(len(signatures)):
   		if signatures[i][1] in header:
   			if (detected == ""):
   				detected = signatures[i][0]
   			else:
   				detected += ','+signatures[i][0]
   	if (detected == ""):
   		detected = "Passed (unknown format)"
   	else:
   		detected = "Failed (%s)" % detected
   		return detected
   	f.save(secure_filename(f.filename))
   	return 'file uploaded successfully'
		
if __name__ == '__main__':
   app.run(debug = True)
